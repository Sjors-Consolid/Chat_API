library(testthat)
library(openapi)

test_check("openapi")
