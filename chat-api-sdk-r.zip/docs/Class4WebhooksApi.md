# Class4WebhooksApi

All URIs are relative to *https://api.chat-api.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SetWebhook**](Class4WebhooksApi.md#SetWebhook) | **POST** /webhook | Sets the URL for receiving webhook


# **SetWebhook**
> SetWebhookStatus SetWebhook(webhook.url)

Sets the URL for receiving webhook

Sets the URL for receiving webhook notifications of new messages and message delivery events (ack).  **API responses in \"Callbacks\" tab**

### Example
```R
library(openapi)

var.webhook.url <- WebhookUrl$new("webhookUrl_example") # WebhookUrl | 

#Sets the URL for receiving webhook
api.instance <- Class4WebhooksApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$SetWebhook(var.webhook.url)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **webhook.url** | [**WebhookUrl**](WebhookUrl.md)|  | 

### Return type

[**SetWebhookStatus**](SetWebhookStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

