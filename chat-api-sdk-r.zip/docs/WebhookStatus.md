# openapi::WebhookStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**msgId** | **character** | message id | [optional] 
**time** | **character** | creation date | [optional] 
**status** | **character** | status name (\&quot;sent\&quot;, \&quot;not sent\&quot;, \&quot;queued\&quot;) | [optional] 


