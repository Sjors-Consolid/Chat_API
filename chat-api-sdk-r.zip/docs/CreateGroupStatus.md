# openapi::CreateGroupStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created** | **character** |  | [optional] 
**message** | **character** | Group creation status | [optional] 
**chatId** | **character** | Created group id | [optional] 
**groupInviteLink** | **character** | Link invitation to the group | [optional] 


