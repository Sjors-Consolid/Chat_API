# openapi::BanSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**banPhoneMask** | **character** |  | 
**preBanMessage** | **character** |  | 
**set** | **character** | Flag indicating that the current request has changed ban settings | 


