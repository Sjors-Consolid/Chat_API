# openapi::GroupParticipantStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**add** | **character** |  | [optional] 
**message** | **character** | Status of adding participant to group | [optional] 
**groupId** | **character** |  | [optional] 


