# openapi::Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **character** | unique id | [optional] 
**body** | **character** | text message for type \&quot;chat\&quot;, or link to download the file for \&quot;ptt\&quot;, \&quot;image\&quot;, \&quot;audio\&quot;, \&quot;video\&quot; and \&quot;document\&quot;, or latitude and longitude for \&quot;location\&quot;, or message \&quot;[Call]\&quot; for \&quot;call_log\&quot; | [optional] 
**type** | **character** | type of the message | [optional] 
**senderName** | **character** | Sender name | [optional] 
**fromMe** | **character** | true - outgoing, false - incoming | [optional] 
**author** | **character** | Author ID of the message, useful for groups | [optional] 
**time** | **integer** | send time, unix timestamp | [optional] 
**chatId** | **character** | chat ID | [optional] 
**messageNumber** | **integer** | sequence number of the message in the database | [optional] 


