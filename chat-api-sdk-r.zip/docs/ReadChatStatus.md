# openapi::ReadChatStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**read** | **character** |  | [optional] 
**message** | **character** | Chat reading status | [optional] 
**chatId** | **character** |  | [optional] 


