# openapi::SendMessageStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sent** | **character** |  | [optional] 
**id** | **character** | unique message id | [optional] 
**message** | **character** | Posting status message | [optional] 


