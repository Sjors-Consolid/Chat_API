# Class5QueuesApi

All URIs are relative to *https://api.chat-api.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ClearActionsQueue**](Class5QueuesApi.md#ClearActionsQueue) | **POST** /clearActionsQueue | Clear outbound actions queue.
[**ClearMessagesQueue**](Class5QueuesApi.md#ClearMessagesQueue) | **POST** /clearMessagesQueue | Clear outbound messages queue.
[**ShowActionsQueue**](Class5QueuesApi.md#ShowActionsQueue) | **GET** /showActionsQueue | Get outbound messages queue.
[**ShowMessagesQueue**](Class5QueuesApi.md#ShowMessagesQueue) | **GET** /showMessagesQueue | Get outbound messages queue.


# **ClearActionsQueue**
> ClearActionsQueueStatus ClearActionsQueue()

Clear outbound actions queue.

This method is needed when you accidentally sent thousands of actions in a row.

### Example
```R
library(openapi)


#Clear outbound actions queue.
api.instance <- Class5QueuesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$ClearActionsQueue()
dput(result)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ClearActionsQueueStatus**](ClearActionsQueueStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **ClearMessagesQueue**
> ClearMessagesQueueStatus ClearMessagesQueue()

Clear outbound messages queue.

This method is needed when you accidentally sent thousands of messages in a row.

### Example
```R
library(openapi)


#Clear outbound messages queue.
api.instance <- Class5QueuesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$ClearMessagesQueue()
dput(result)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ClearMessagesQueueStatus**](ClearMessagesQueueStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **ShowActionsQueue**
> OutboundActions ShowActionsQueue()

Get outbound messages queue.

When you create an action, all actions are queued up. If an action is not executed, it remains in the queue and will be sent for execution in time. again. The action cannot be executed due to the status of the device connected to the account.  This method give the last 100 actions in the queue.

### Example
```R
library(openapi)


#Get outbound messages queue.
api.instance <- Class5QueuesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$ShowActionsQueue()
dput(result)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**OutboundActions**](OutboundActions.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **ShowMessagesQueue**
> OutboundMessages ShowMessagesQueue()

Get outbound messages queue.

When sending messages, all messages are in the queue. If the message is not sent, then it remains in the queue and in time it will be sent again. The message may not be sent due to the status of the device connected to the account.   This method give the last 100 messages in the queue.

### Example
```R
library(openapi)


#Get outbound messages queue.
api.instance <- Class5QueuesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$ShowMessagesQueue()
dput(result)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**OutboundMessages**](OutboundMessages.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

