# openapi::InstanceStatusLink

Status information link
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**label** | **character** | Link caption for the button | [optional] 
**link** | **character** | Reference URL instead of method | [optional] 


