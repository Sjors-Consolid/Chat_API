# openapi::CreateGroupAction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupName** | **character** | Name of the group being created | 
**chatIds** | **array[character]** | **Required if phones is not set**  An array of new participients chatIds.  | [optional] 
**phones** | **array[integer]** | **Required if chatIds is not set**  An array of phones starting with the country code. You do not need to add your number.   USA example: [17472822486&#39;]. | [optional] 
**messageText** | **character** | The text of the message that will be sent to the group when it is created. If you do not set a parameter, the message will not be sent | [optional] 


