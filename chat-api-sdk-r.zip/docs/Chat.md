# openapi::Chat

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **character** | chat id | [optional] 
**name** | **character** | chat name | [optional] 
**image** | **character** | HTTPS link on avatar or group image | [optional] 
**metadata** | [**object**](.md) | Additional info about chat | [optional] 


