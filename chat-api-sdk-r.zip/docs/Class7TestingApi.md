# Class7TestingApi

All URIs are relative to *https://api.chat-api.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**InstanceStatuses**](Class7TestingApi.md#InstanceStatuses) | **GET** /instanceStatuses | Returns instance status changes history.
[**WebhookStatuses**](Class7TestingApi.md#WebhookStatuses) | **GET** /webhookStatus | Returns webhook status for message.


# **InstanceStatuses**
> Statuses InstanceStatuses(min.time=var.min.time, max.time=var.max.time)

Returns instance status changes history.

Requires enable \"instanceStatuses\" option for collecting data.

### Example
```R
library(openapi)

var.min.time <- 946684800 # integer | Filter statuses received after specified date. Example: 946684800.
var.max.time <- 946684800 # integer | Filter statuses received before specified date. Example: 946684800.

#Returns instance status changes history.
api.instance <- Class7TestingApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$InstanceStatuses(min.time=var.min.time, max.time=var.max.time)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **min.time** | **integer**| Filter statuses received after specified date. Example: 946684800. | [optional] 
 **max.time** | **integer**| Filter statuses received before specified date. Example: 946684800. | [optional] 

### Return type

[**Statuses**](Statuses.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **WebhookStatuses**
> WebhookStatus WebhookStatuses(msg.id)

Returns webhook status for message.

Requires enable \"webhookStatuses\" option for collecting data.

### Example
```R
library(openapi)

var.msg.id <- 'false_17472822486@c.us_DF38E6A25B42CC8CCE57EC40F' # character | Message ID. Example: false_17472822486@c.us_DF38E6A25B42CC8CCE57EC40F.

#Returns webhook status for message.
api.instance <- Class7TestingApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$WebhookStatuses(var.msg.id)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **msg.id** | **character**| Message ID. Example: false_17472822486@c.us_DF38E6A25B42CC8CCE57EC40F. | 

### Return type

[**WebhookStatus**](WebhookStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

