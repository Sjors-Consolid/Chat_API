# Class3ChatsApi

All URIs are relative to *https://api.chat-api.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**AddGroupParticipant**](Class3ChatsApi.md#AddGroupParticipant) | **POST** /addGroupParticipant | Adding participant to a group
[**DemoteGroupParticipant**](Class3ChatsApi.md#DemoteGroupParticipant) | **POST** /demoteGroupParticipant | Demote group participant
[**GetChats**](Class3ChatsApi.md#GetChats) | **GET** /dialogs | Get the chat list.
[**Group**](Class3ChatsApi.md#Group) | **POST** /group | Creates a group and sends the message to the created group.
[**PromoteGroupParticipant**](Class3ChatsApi.md#PromoteGroupParticipant) | **POST** /promoteGroupParticipant | Make participant in the group an administrator
[**ReadChat**](Class3ChatsApi.md#ReadChat) | **POST** /readChat | Open chat for reading messages
[**RemoveGroupParticipant**](Class3ChatsApi.md#RemoveGroupParticipant) | **POST** /removeGroupParticipant | Remove participant from a group


# **AddGroupParticipant**
> GroupParticipantStatus AddGroupParticipant(group.participant.action)

Adding participant to a group

### Example
```R
library(openapi)

var.group.participant.action <- GroupParticipantAction$new("groupId_example", "participantChatId_example", 123) # GroupParticipantAction | 

#Adding participant to a group
api.instance <- Class3ChatsApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$AddGroupParticipant(var.group.participant.action)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group.participant.action** | [**GroupParticipantAction**](GroupParticipantAction.md)|  | 

### Return type

[**GroupParticipantStatus**](GroupParticipantStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **DemoteGroupParticipant**
> GroupParticipantStatus DemoteGroupParticipant(group.participant.action)

Demote group participant

### Example
```R
library(openapi)

var.group.participant.action <- GroupParticipantAction$new("groupId_example", "participantChatId_example", 123) # GroupParticipantAction | 

#Demote group participant
api.instance <- Class3ChatsApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$DemoteGroupParticipant(var.group.participant.action)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group.participant.action** | [**GroupParticipantAction**](GroupParticipantAction.md)|  | 

### Return type

[**GroupParticipantStatus**](GroupParticipantStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **GetChats**
> Chats GetChats()

Get the chat list.

The chat list includes avatars.

### Example
```R
library(openapi)


#Get the chat list.
api.instance <- Class3ChatsApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$GetChats()
dput(result)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Chats**](Chats.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **Group**
> CreateGroupStatus Group(create.group.action)

Creates a group and sends the message to the created group.

The group will be added to the queue for sending and sooner or later it will be created, even if the phone is disconnected from the Internet or the authorization is not passed.   2 Oct 2018 update: chatId parameter will be returned if group was created on your phone within 20 second.

### Example
```R
library(openapi)

var.create.group.action <- CreateGroupAction$new("groupName_example", list("chatIds_example"), list(123), "messageText_example") # CreateGroupAction | 

#Creates a group and sends the message to the created group.
api.instance <- Class3ChatsApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$Group(var.create.group.action)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **create.group.action** | [**CreateGroupAction**](CreateGroupAction.md)|  | 

### Return type

[**CreateGroupStatus**](CreateGroupStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **PromoteGroupParticipant**
> GroupParticipantStatus PromoteGroupParticipant(group.participant.action)

Make participant in the group an administrator

### Example
```R
library(openapi)

var.group.participant.action <- GroupParticipantAction$new("groupId_example", "participantChatId_example", 123) # GroupParticipantAction | 

#Make participant in the group an administrator
api.instance <- Class3ChatsApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$PromoteGroupParticipant(var.group.participant.action)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group.participant.action** | [**GroupParticipantAction**](GroupParticipantAction.md)|  | 

### Return type

[**GroupParticipantStatus**](GroupParticipantStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **ReadChat**
> ReadChatStatus ReadChat(read.chat.action)

Open chat for reading messages

Use this method to make users see their messages read.

### Example
```R
library(openapi)

var.read.chat.action <- ReadChatAction$new("chatId_example", "phone_example") # ReadChatAction | 

#Open chat for reading messages
api.instance <- Class3ChatsApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$ReadChat(var.read.chat.action)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **read.chat.action** | [**ReadChatAction**](ReadChatAction.md)|  | 

### Return type

[**ReadChatStatus**](ReadChatStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **RemoveGroupParticipant**
> GroupParticipantStatus RemoveGroupParticipant(group.participant.action)

Remove participant from a group

### Example
```R
library(openapi)

var.group.participant.action <- GroupParticipantAction$new("groupId_example", "participantChatId_example", 123) # GroupParticipantAction | 

#Remove participant from a group
api.instance <- Class3ChatsApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$RemoveGroupParticipant(var.group.participant.action)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **group.participant.action** | [**GroupParticipantAction**](GroupParticipantAction.md)|  | 

### Return type

[**GroupParticipantStatus**](GroupParticipantStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

