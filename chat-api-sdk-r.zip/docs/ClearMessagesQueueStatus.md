# openapi::ClearMessagesQueueStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **character** | Messages queue clear status | [optional] 
**messageTextsExample** | **array[character]** | Content of the first hundred messages from the cleaned queue | [optional] 


