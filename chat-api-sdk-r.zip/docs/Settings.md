# openapi::Settings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**webhookUrl** | **character** |  | [optional] 
**ackNotificationsOn** | **character** |  | [optional] 
**chatUpdateOn** | **character** |  | [optional] 
**videoUploadOn** | **character** |  | [optional] 
**proxy** | **character** |  | [optional] 
**guaranteedHooks** | **character** |  | [optional] 
**ignoreOldMessages** | **character** |  | [optional] 
**processArchive** | **character** |  | [optional] 
**instanceStatuses** | **character** |  | [optional] 
**webhookStatuses** | **character** |  | [optional] 
**statusNotificationsOn** | **character** |  | [optional] 


