# openapi::ClearActionsQueueStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **character** | Actions queue clear status | [optional] 
**actionsExample** | **array[character]** | Type of the first hundred actions from the cleaned queue | [optional] 


