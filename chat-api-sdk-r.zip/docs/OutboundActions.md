# openapi::OutboundActions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalActions** | **integer** | Total number of actions in the queue | [optional] 
**first100** | [**array[OutboundAction]**](OutboundAction.md) |  | [optional] 


