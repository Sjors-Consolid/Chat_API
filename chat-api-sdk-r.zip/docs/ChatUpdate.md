# openapi::ChatUpdate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**old** | [**Chat**](Chat.md) |  | [optional] 
**new** | [**Chat**](Chat.md) |  | [optional] 


