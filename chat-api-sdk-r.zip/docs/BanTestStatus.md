# openapi::BanTestStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**banned** | **character** |  | [optional] 
**message** | **character** |  | [optional] 
**phone** | **character** | Test phone number | [optional] 
**banPhoneMask** | **character** | Test regex | [optional] 


