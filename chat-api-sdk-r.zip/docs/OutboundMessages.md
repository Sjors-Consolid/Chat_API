# openapi::OutboundMessages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**totalMessages** | **integer** | Total number of messages in the queue | [optional] 
**first100** | [**array[OutboundMessage]**](OutboundMessage.md) |  | [optional] 


