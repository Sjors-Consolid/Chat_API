# openapi::InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**webhookUrl** | **character** |  | [optional] 
**ackNotificationsOn** | **character** |  | [optional] 
**chatUpdateOn** | **character** |  | [optional] 
**videoUploadOn** | **character** |  | [optional] 
**proxy** | **character** |  | [optional] 
**guaranteedHooks** | **character** |  | [optional] 
**ignoreOldMessages** | **character** |  | [optional] 
**processArchive** | **character** |  | [optional] 
**instanceStatuses** | **character** |  | [optional] 
**webhookStatuses** | **character** |  | [optional] 
**statusNotificationsOn** | **character** |  | [optional] 
**update** | [**InlineResponse2005Update**](inline_response_200_5_update.md) |  | 


