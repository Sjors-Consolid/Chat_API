# openapi::Ack

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **character** | unique id | [optional] 
**queueNumber** | **integer** | message id in queue | [optional] 
**chatId** | **character** | chat ID | [optional] 
**status** | **character** | type of the message status | [optional] 


