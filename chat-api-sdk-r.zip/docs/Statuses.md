# openapi::Statuses

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**array[Status]**](Status.md) |  | [optional] 


