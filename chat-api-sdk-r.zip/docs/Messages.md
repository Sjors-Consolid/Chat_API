# openapi::Messages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**messages** | [**array[Message]**](Message.md) |  | [optional] 
**lastMessageNumber** | **integer** | next query should be /messages?lastMessageNumber&#x3D;199 | [optional] 


