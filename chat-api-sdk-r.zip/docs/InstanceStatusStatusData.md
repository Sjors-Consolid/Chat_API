# openapi::InstanceStatusStatusData

More information about instance status
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**substatus** | **character** | Instance Substatus | [optional] 
**title** | **character** | Status title in the language of the instance | [optional] 
**msg** | **character** | Status message in the language of the instance | [optional] 
**submsg** | **character** | Additional status message in the language of the instance | [optional] 
**actions** | [**InstanceStatusStatusDataActions**](InstanceStatus_statusData_actions.md) |  | [optional] 
**reason** | **character** | The reason why the instance is in \&quot;loading\&quot; status | [optional] 


