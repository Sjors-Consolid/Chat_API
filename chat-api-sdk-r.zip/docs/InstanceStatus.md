# openapi::InstanceStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountStatus** | **character** | Instance Status | [optional] 
**qrCode** | **character** | Base64-encoded contents of the QR code | [optional] 
**statusData** | [**InstanceStatusStatusData**](InstanceStatus_statusData.md) |  | [optional] 


