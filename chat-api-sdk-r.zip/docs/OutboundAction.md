# openapi::OutboundAction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **integer** | action id in queue | [optional] 
**type** | **character** | type of the action in queue | [optional] 
**last_try** | **integer** | Last try time to execute a action | [optional] 
**json_data** | [**object**](.md) | Additional action data | [optional] 


