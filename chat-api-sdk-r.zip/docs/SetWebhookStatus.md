# openapi::SetWebhookStatus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**set** | **character** | Flag indicating that the current request has changed webhook | [optional] 
**message** | **character** |  | [optional] 


