# openapi::InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **character** |  | [optional] [default to TRUE]


