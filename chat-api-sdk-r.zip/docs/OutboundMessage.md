# openapi::OutboundMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **integer** | message id in queue | [optional] 
**body** | **character** | text message in queue | [optional] 
**type** | **character** | type of the message in queue | [optional] 
**last_try** | **integer** | Last try time to send a message | [optional] 
**metadata** | [**object**](.md) | Additional message data | [optional] 


