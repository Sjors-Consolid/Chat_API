# openapi::Chats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dialogs** | [**array[Chat]**](Chat.md) |  | [optional] 


