# openapi::Status

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**date** | **character** | status date | [optional] 
**status** | **character** | status name (\&quot;init\&quot;, \&quot;got qr code\&quot;, \&quot;loading\&quot;, \&quot;authenticated\&quot;) | [optional] 


