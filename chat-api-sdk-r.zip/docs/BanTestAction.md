# openapi::BanTestAction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phone** | **character** | A phone number starting with the country code. USA example: \&quot;17472822486\&quot;. | 


