# Class6BanApi

All URIs are relative to *https://api.chat-api.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**BanTest**](Class6BanApi.md#BanTest) | **POST** /banTest | Test ban settings
[**GetBanSettings**](Class6BanApi.md#GetBanSettings) | **GET** /banSettings | Get settings
[**SetBanSettings**](Class6BanApi.md#SetBanSettings) | **POST** /banSettings | Set settings


# **BanTest**
> BanTestStatus BanTest(ban.test.action)

Test ban settings

Send the phone number to find out if the instance is banning it

### Example
```R
library(openapi)

var.ban.test.action <- BanTestAction$new("phone_example") # BanTestAction | 

#Test ban settings
api.instance <- Class6BanApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$BanTest(var.ban.test.action)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ban.test.action** | [**BanTestAction**](BanTestAction.md)|  | 

### Return type

[**BanTestStatus**](BanTestStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **GetBanSettings**
> BanSettings GetBanSettings()

Get settings

**banPhoneMask** - Regular expression on which bans on numbers will be sent  **preBanMessage** - Warning message If it is set, a message will be sent before sending the ban.

### Example
```R
library(openapi)


#Get settings
api.instance <- Class6BanApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$GetBanSettings()
dput(result)
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**BanSettings**](BanSettings.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **SetBanSettings**
> BanSettings SetBanSettings(ban.settings)

Set settings

**banPhoneMask** - Regular expression on which bans on numbers will be sent  **preBanMessage** - Warning message If it is set, a message will be sent before sending the ban.

### Example
```R
library(openapi)

var.ban.settings <- BanSettings$new("banPhoneMask_example", "preBanMessage_example", "set_example") # BanSettings | 

#Set settings
api.instance <- Class6BanApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$SetBanSettings(var.ban.settings)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ban.settings** | [**BanSettings**](BanSettings.md)|  | 

### Return type

[**BanSettings**](BanSettings.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/json, application/x-www-form-urlencoded
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

