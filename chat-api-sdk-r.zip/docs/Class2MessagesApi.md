# Class2MessagesApi

All URIs are relative to *https://api.chat-api.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**ForwardMessage**](Class2MessagesApi.md#ForwardMessage) | **POST** /forwardMessage | Forwarding messages to a new or existing chat.
[**GetMessages**](Class2MessagesApi.md#GetMessages) | **GET** /messages | Get a list of messages.
[**SendContact**](Class2MessagesApi.md#SendContact) | **POST** /sendContact | Sending a contact or contact list to a new or existing chat.
[**SendFile**](Class2MessagesApi.md#SendFile) | **POST** /sendFile | Send a file to a new or existing chat.
[**SendLink**](Class2MessagesApi.md#SendLink) | **POST** /sendLink | Send text with link and link&#39;s preview to a new or existing chat.
[**SendLocation**](Class2MessagesApi.md#SendLocation) | **POST** /sendLocation | Sending a location to a new or existing chat.
[**SendMessage**](Class2MessagesApi.md#SendMessage) | **POST** /sendMessage | Send a message to a new or existing chat.
[**SendPTT**](Class2MessagesApi.md#SendPTT) | **POST** /sendPTT | Send a ptt-audio to a new or existing chat.
[**SendVCard**](Class2MessagesApi.md#SendVCard) | **POST** /sendVCard | Sending a vcard to a new or existing chat.


# **ForwardMessage**
> SendMessageStatus ForwardMessage(forward.message.request)

Forwarding messages to a new or existing chat.

Only one of two parameters is needed to determine the destination - chatId or phone.

### Example
```R
library(openapi)

var.forward.message.request <- ForwardMessageRequest$new("chatId_example", 123, "messageId_example") # ForwardMessageRequest | 

#Forwarding messages to a new or existing chat.
api.instance <- Class2MessagesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$ForwardMessage(var.forward.message.request)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **forward.message.request** | [**ForwardMessageRequest**](ForwardMessageRequest.md)|  | 

### Return type

[**SendMessageStatus**](SendMessageStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **GetMessages**
> Messages GetMessages(last.message.number=var.last.message.number, last=FALSE, chat.id=var.chat.id, limit=var.limit, min.time=var.min.time, max.time=var.max.time)

Get a list of messages.

To receive only new messages, pass the **lastMessageNumber** parameter from the last query.  Files from messages are guaranteed to be stored only for 30 days and can be deleted. Download the files as soon as you get to your server.

### Example
```R
library(openapi)

var.last.message.number <- 0 # integer | The lastMessageNumber parameter from the last response
var.last <- FALSE # character | Displays the last 100 messages. If this parameter is passed, then lastMessageNumber is ignored.
var.chat.id <- '17633123456@c.us' # character | Filter messages by chatId  Chat ID from the message list. Examples: 17633123456@c.us for private messages and 17680561234-1479621234@g.us for the group.
var.limit <- 100 # integer | Sets length of the message list. Default 100. With value 0 returns all messages.
var.min.time <- 946684800 # integer | Filter messages received after specified time. Example: 946684800.
var.max.time <- 946684800 # integer | Filter messages received before specified time. Example: 946684800.

#Get a list of messages.
api.instance <- Class2MessagesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$GetMessages(last.message.number=var.last.message.number, last=var.last, chat.id=var.chat.id, limit=var.limit, min.time=var.min.time, max.time=var.max.time)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **last.message.number** | **integer**| The lastMessageNumber parameter from the last response | [optional] 
 **last** | **character**| Displays the last 100 messages. If this parameter is passed, then lastMessageNumber is ignored. | [optional] [default to FALSE]
 **chat.id** | **character**| Filter messages by chatId  Chat ID from the message list. Examples: 17633123456@c.us for private messages and 17680561234-1479621234@g.us for the group. | [optional] 
 **limit** | **integer**| Sets length of the message list. Default 100. With value 0 returns all messages. | [optional] 
 **min.time** | **integer**| Filter messages received after specified time. Example: 946684800. | [optional] 
 **max.time** | **integer**| Filter messages received before specified time. Example: 946684800. | [optional] 

### Return type

[**Messages**](Messages.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **SendContact**
> SendMessageStatus SendContact(send.contact.request)

Sending a contact or contact list to a new or existing chat.

Only one of two parameters is needed to determine the destination - chatId or phone.

### Example
```R
library(openapi)

var.send.contact.request <- SendContactRequest$new("chatId_example", 123, "contactId_example") # SendContactRequest | 

#Sending a contact or contact list to a new or existing chat.
api.instance <- Class2MessagesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$SendContact(var.send.contact.request)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **send.contact.request** | [**SendContactRequest**](SendContactRequest.md)|  | 

### Return type

[**SendMessageStatus**](SendMessageStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **SendFile**
> SendMessageStatus SendFile(send.file.request)

Send a file to a new or existing chat.

Only one of two parameters is needed to determine the destination - chatId or phone.

### Example
```R
library(openapi)

var.send.file.request <- SendFileRequest$new("chatId_example", 123, "body_example", "filename_example", "caption_example") # SendFileRequest | 

#Send a file to a new or existing chat.
api.instance <- Class2MessagesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$SendFile(var.send.file.request)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **send.file.request** | [**SendFileRequest**](SendFileRequest.md)|  | 

### Return type

[**SendMessageStatus**](SendMessageStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **SendLink**
> SendMessageStatus SendLink(send.link.request)

Send text with link and link's preview to a new or existing chat.

Only one of two parameters is needed to determine the destination - chatId or phone.

### Example
```R
library(openapi)

var.send.link.request <- SendLinkRequest$new("chatId_example", 123, "body_example", "previewBase64_example", "title_example", "description_example") # SendLinkRequest | 

#Send text with link and link's preview to a new or existing chat.
api.instance <- Class2MessagesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$SendLink(var.send.link.request)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **send.link.request** | [**SendLinkRequest**](SendLinkRequest.md)|  | 

### Return type

[**SendMessageStatus**](SendMessageStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **SendLocation**
> SendMessageStatus SendLocation(send.location.request)

Sending a location to a new or existing chat.

Only one of two parameters is needed to determine the destination - chatId or phone.

### Example
```R
library(openapi)

var.send.location.request <- SendLocationRequest$new("chatId_example", 123, 123, 123, "address_example") # SendLocationRequest | 

#Sending a location to a new or existing chat.
api.instance <- Class2MessagesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$SendLocation(var.send.location.request)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **send.location.request** | [**SendLocationRequest**](SendLocationRequest.md)|  | 

### Return type

[**SendMessageStatus**](SendMessageStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **SendMessage**
> SendMessageStatus SendMessage(send.message.request)

Send a message to a new or existing chat.

The message will be added to the queue for sending and delivered even if the phone is disconnected from the Internet or authorization is not passed.  Only one of two parameters is needed to determine the destination - chatId or phone.

### Example
```R
library(openapi)

var.send.message.request <- SendMessageRequest$new("chatId_example", 123, "body_example") # SendMessageRequest | 

#Send a message to a new or existing chat.
api.instance <- Class2MessagesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$SendMessage(var.send.message.request)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **send.message.request** | [**SendMessageRequest**](SendMessageRequest.md)|  | 

### Return type

[**SendMessageStatus**](SendMessageStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **SendPTT**
> SendMessageStatus SendPTT(send.ptt.request)

Send a ptt-audio to a new or existing chat.

Only one of two parameters is needed to determine the destination - chatId or phone.

### Example
```R
library(openapi)

var.send.ptt.request <- SendPTTRequest$new("chatId_example", 123, "audio_example") # SendPTTRequest | 

#Send a ptt-audio to a new or existing chat.
api.instance <- Class2MessagesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$SendPTT(var.send.ptt.request)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **send.ptt.request** | [**SendPTTRequest**](SendPTTRequest.md)|  | 

### Return type

[**SendMessageStatus**](SendMessageStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

# **SendVCard**
> SendMessageStatus SendVCard(send.v.card.request)

Sending a vcard to a new or existing chat.

Only one of two parameters is needed to determine the destination - chatId or phone.

### Example
```R
library(openapi)

var.send.v.card.request <- SendVCardRequest$new("chatId_example", 123, "vcard_example") # SendVCardRequest | 

#Sending a vcard to a new or existing chat.
api.instance <- Class2MessagesApi$new()
# Configure API key authorization: instanceId
api.instance$apiClient$apiKeys['instanceId'] <- 'TODO_YOUR_API_KEY';
# Configure API key authorization: token
api.instance$apiClient$apiKeys['token'] <- 'TODO_YOUR_API_KEY';
result <- api.instance$SendVCard(var.send.v.card.request)
dput(result)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **send.v.card.request** | [**SendVCardRequest**](SendVCardRequest.md)|  | 

### Return type

[**SendMessageStatus**](SendMessageStatus.md)

### Authorization

[instanceId](../README.md#instanceId), [token](../README.md#token)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

### HTTP response details
| Status code | Description | Response headers |
|-------------|-------------|------------------|
| **200** | Server response example |  -  |

