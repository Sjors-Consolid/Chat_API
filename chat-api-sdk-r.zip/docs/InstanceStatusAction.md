# openapi::InstanceStatusAction

Action for change status
## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**act** | **character** | Method name | [optional] 
**label** | **character** | Action caption for the button | [optional] 


